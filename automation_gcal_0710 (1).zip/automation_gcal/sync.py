from __future__ import print_function

import datetime
import os.path
from pprint import pprint
import json
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

import things

# google calendars IDs
# Basically, the id has to be between 5 and 1024 characters and be composed from characters in this alphabet : 0123456789abcdefghijklmnopqrstuv
PROJECTS_CAL_NAME = "Projects"
TODOS_CAL_NAME = "Todos"

# If modifying these scopes, delete the file token.json.
# SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
SCOPES = ['https://www.googleapis.com/auth/calendar']


def print_log(string, variable):
    '''
    print Log
    '''
    print(string)
    print(variable)
    print("===============")


def addCheckMark(text):
    '''
    Mark as completed
    '''
    return '✅ ' + text


def addStartDateMark(text):
    '''
    Mark as start date
    '''
    return '🚀 ' + text


def addDeadlineMark(text):
    '''
    Mark as start date
    '''
    return '🆘 ' + text


def authorize():
    '''
    google authorization (oauth2)
    '''

    creds = None

    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.

    token_path = os.path.dirname(os.path.realpath(__file__)) + '/token.json'
    credentials_path = os.path.dirname(os.path.realpath(__file__)) + '/credentials.json'

    try:
        if os.path.exists(token_path):
            creds = Credentials.from_authorized_user_file(token_path, SCOPES)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open(token_path, 'w') as token:
                token.write(creds.to_json())
    except Exception as e:
        return None

    return creds


def createCalendarsIfNotExists(service):
    '''
    create calendars if does not exist
    '''

    results = service.calendarList().list().execute()
    calsList = results.get('items')

    projects_cal = None
    projectsCal = list( filter(lambda el: el["summary"] == PROJECTS_CAL_NAME, calsList) )
    if len(projectsCal) == 0:
        print("\"Projects\" calendar does not exist, creating one..")
        try:
            projects_cal_obj = {
                'summary': PROJECTS_CAL_NAME
            }
            projects_cal = service.calendars().insert(body = projects_cal_obj).execute()
            # print(projects_cal)
        except Exception as e:
            print(e)
            return None
    else:
        projects_cal = projectsCal[0]

    todos_cal = None
    todosCal = list( filter(lambda el: el["summary"] == TODOS_CAL_NAME, calsList) )
    if len(todosCal) == 0:
        print("\"Todos\" calendar does not exist, creating one..")
        try: 
            todos_cal_obj = {
                "summary": TODOS_CAL_NAME
            }
            todos_cal = service.calendars().insert(body = todos_cal_obj).execute()
            print(todos_cal)
        except Exception as e:
            print(e)
            return None
    else:
        todos_cal = todosCal[0]

    return {
        "project": projects_cal,
        "todo": todos_cal
    }
    

def loadTasksFromThingsApp():
    '''
    load tasks from Things app
    '''

    # check if it's initial sync
    initial_sync = True
    first_sync_for_today = False
    last_run_time = ''
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_file = "last_run_time.txt"

    if Path(str(Path(__file__).parent.resolve()) + "/" + log_file).exists():
        with open(str(Path(__file__).parent.resolve()) + "/" + log_file, 'r') as f:
            for line in f:
                pass

            try:
                last_run_time = line
                initial_sync = False
                if datetime.datetime.strftime(datetime.datetime.strptime(current_time, '%Y-%m-%d %H:%M:%S'), '%Y-%m-%d') != datetime.datetime.strftime(datetime.datetime.strptime(last_run_time, '%Y-%m-%d %H:%M:%S'), '%Y-%m-%d'):
                    first_sync_for_today = True
            except NameError:
                last_run_time = current_time
    else:
        last_run_time = current_time
        
    f = open(os.path.join(Path(__file__).parent.resolve(), log_file), 'w')
    f.write(current_time)
    f.close()
    # print("initial_sync? ", initial_sync)
    # print("first_sync_for_today? ", first_sync_for_today)

    try:
        # read Today's tasks into dicts
        tasks_for_today = things.today()
        if not initial_sync and not first_sync_for_today:
            tasks_for_today = list( filter( lambda el: datetime.datetime.strptime(el["modified"], "%Y-%m-%d %H:%M:%S") > datetime.datetime.strptime(last_run_time, "%Y-%m-%d %H:%M:%S"), tasks_for_today ) )
        task_uuids_for_today = list (task["uuid"] for task in tasks_for_today)
        # print(task_uuids_for_today)

        # get all projects
        completed_projects = things.projects(status='completed')
        incompleted_projects = things.projects()
        all_projects = completed_projects + incompleted_projects
        if not initial_sync: 
            all_projects = list( filter( lambda el: datetime.datetime.strptime(el["modified"], "%Y-%m-%d %H:%M:%S") > datetime.datetime.strptime(last_run_time, "%Y-%m-%d %H:%M:%S"), all_projects ) )
        all_projects = list( filter( lambda el: el["uuid"] not in task_uuids_for_today, all_projects ) )

        # get all todos
        completed_todos = things.todos(status='completed')
        incompleted_todos = things.todos()
        all_todos = completed_todos + incompleted_todos
        if not initial_sync:
            all_todos = list( filter( lambda el: datetime.datetime.strptime(el["modified"], "%Y-%m-%d %H:%M:%S") > datetime.datetime.strptime(last_run_time, "%Y-%m-%d %H:%M:%S"), all_todos ) )
        all_todos = list( filter( lambda el: el["uuid"] not in task_uuids_for_today, all_todos ) )
    except Exception as e:
        return None

    return {
        "today": tasks_for_today,
        "projects": all_projects,
        "todos": all_todos
    }


def addEvent(task, service, calsList, task_for_today = False):
    '''
    Create an Event
    '''

    try:
        calendar_id = None
        if task["type"] == "to-do":
            calendar_id = calsList["todo"]["id"]
        elif task["type"] == "project":
            calendar_id = calsList["project"]["id"]

        event = {
            "iCalUID": task["uuid"],
            "summary": task["title"],
            "description": task["notes"],
            # "start": {
            #     "date": None,
            #     "dateTime": None
            # },
            # "end": {
            #     "date": None,
            #     "dateTime": None
            # }
        }

        if task["status"] == 'completed':
            event["start"] = { "date": task["stop_date"] }
            event["end"] = { "date": task["stop_date"] }
            event["summary"] = addCheckMark( task["title"] )
        elif task["status"] == 'incomplete':
            # set event start date & end date
            if task_for_today == True:
                event["start"] = { "date": datetime.datetime.today().strftime('%Y-%m-%d') }
                event["end"] = { "date": datetime.datetime.today().strftime('%Y-%m-%d') }
                event["summary"] = addStartDateMark( task["title"] )
            else:
                if task["start_date"] :
                    if task["deadline"]:
                        start_time = datetime.time.strptime(task["start_date"], "%Y-%m-%d")
                        deadline = datetime.time.strptime(task["deadline"], "%Y-%m-%d")

                        if (deadline > start_time):
                            event["start"] = { "date": task["start_date"] }
                            event["end"] = { "date": task["deadline"] }
                        else:
                            event["start"] = { "date": task["start_date"] }
                            event["end"] = { "date": task["start_date"] }
                            event["summary"] = addStartDateMark( task["title"] )
                    else:
                        event["start"] = { "date": task["start_date"] }
                        event["end"] = { "date": task["start_date"] }
                        event["summary"] = addStartDateMark( task["title"] )
                else:
                    if task["deadline"]:
                        event["start"] = { "date": task["deadline"] }
                        event["end"] = { "date": task["deadline"] }
                        event["summary"] = addDeadlineMark( task["title"] )
                    else:
                        # none of date fields are available
                        # print("skipped")
                        return False

        # print(calendar_id, event)
        # print("==================")
        try:
            event_obj = service.events().insert(calendarId = calendar_id, body = event).execute()
        except Exception as add_err:
            error_code = json.loads(add_err.content)["error"]["code"]
            # print(error_code, type(error_code))

            if error_code and error_code == 409:
                # conflicts: already exists
                existing_event = service.events().list(calendarId = calendar_id, iCalUID = task["uuid"]).execute()["items"][0]
                # print(existing_event)
                try:
                    event_obj = service.events().update(calendarId = calendar_id, eventId = existing_event["id"], body = event).execute()
                except Exception as update_err:
                    print("Event update has failed!", update_err)
                    return False
                return True
            print("Event add has failed!", add_err)
            return False

    except Exception as e:
        # print(e)
        print("Sorry, something went wrong on adding/updating an event.")
        return False

    return True


def main():
    '''
    main workflow
    '''

    creds = None
    creds = authorize()

    if creds is None:
        print("Not Authorized!")
        exit()

    try:
        service = build('calendar', 'v3', credentials=creds)

        # Create calendars if not exists
        calsList = createCalendarsIfNotExists(service)
        # print(calsList)
        if calsList is None:
            print("ERROR: Cannot create calendars. ")
            exit()

        # load projects & todos from Things app
        tasks = loadTasksFromThingsApp()
        # print(tasks)
        if tasks is None:
            print("ERROR: Cannot load tasks from Things App. ")
            exit()

        # add events to google calendar
        for project in tasks["projects"]:
            # print(project["uuid"], project["title"])
            project_sync_result = addEvent(project, service, calsList)
            # print(project_sync_result)

        for todo in tasks["todos"]:
            # print(todo["uuid"], todo["title"])
            todo_sync_result = addEvent(todo, service, calsList)
            # print(todo_sync_result)

        for task in tasks["today"]:
            print(task["uuid"], task["title"])
            task_sync_result = addEvent(task, service, calsList, True)
            print(task_sync_result)

    except Exception as e:
        print('Sorry, something went wrong.', e)


# start
if __name__ == '__main__':
    main()
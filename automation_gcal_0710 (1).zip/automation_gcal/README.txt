1. Download credentials from google (JSON file) and move it to the project folder and rename it as "credentials.json". 

2. Install venv package globally
python3 -m pip install --user virtualenv

3. Activate virtual env
source [path to project folder]/venv/bin/activate

4. Install packages
pip3 install -r requirements.txt

5. Run the script using the command below:
python3 sync.py
On the first run, you will be asked to authorize on google, and once you authorized, the script will create a "token.json" file to use access_token for further API requests.
